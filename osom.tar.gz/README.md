awesome_config
==============

u can specify theme and screen resolution in `widgets/setting.lua`
