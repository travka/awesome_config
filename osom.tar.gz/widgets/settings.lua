local settings = {
	theme_dir = "/themes/actionless/",
	screen_width = 1366,
	screen_height = 768
}

return settings
